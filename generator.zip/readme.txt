To use:

1) Extract all the contents of this zip file into a new folder.

2) In the new folder, double-click on the "index.html" file to open the generator in your browser.

THE INDEX.HTML FILE WON'T OPEN PROPERLY IF YOU OPEN IT FROM WITHIN THE ZIP FILE WITHOUT EXRACTING EVERYTHING FIRST!

For full instructions, see the "man.html" file.


