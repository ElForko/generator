To use:

1) Unzip this zip file into a new folder.

2) Double-click the "index.html" file to open the generator in your browser.

THE INDEX.HTML FILE WON'T OPEN PROPERLY IF YOU OPEN IT FROM WITHIN THE ZIP FILE WITHOUT UNZIPPING EVERYTHING FIRST!

For full instructions, see the "man.html" file.


